import java.util.ArrayList;
import java.util.List;

public class Referee extends Admin {
    private List<String> certifications;

    public Referee(String name, String imageIdUrl) {
        super(name, imageIdUrl);
        this.certifications = new ArrayList<>();
    }

    public List<String> getCertifications() {
        return this.certifications;
    }

    public void addCertifications(String certification) {
        this.certifications.add(certification);
    }

    public void assignYellowCard(int playerId) {
        System.out.println("Referee gave yellow card to player " + playerId);
    }

    public void assignRedCard(int playerId) {
        System.out.println("Referee gave red card to player " + playerId);
    }

    @Override
    public String toString() {
        return "{\n" +
                "\tid: " + this.getId() + "\n" + 
                "\tname: " + this.getName() + "\n" + 
                "\timageIdUrl: " + this.getImageIdUrl() + "\n" +
                "\tisIdApproved: " + this.getIsIdApproved() + "\n" +
                "\tcertifications: " + this.certifications + "\n" +
                "}\n";
    }

    @Override
    public boolean equals(Object obj) {
        return (obj instanceof Referee otherRef)
            && this.getId() == otherRef.getId()
            && this.getName().equalsIgnoreCase(otherRef.getName())
            && this.getImageIdUrl() == otherRef.getImageIdUrl()
            && this.getIsIdApproved() == otherRef.getIsIdApproved()
            && this.certifications.equals(otherRef.certifications); 
    }
}
